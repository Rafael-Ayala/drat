# Constants and tables

Cnm <- matrix(0L, nrow=181, ncol=181)
Snm <- matrix(0L, nrow=181, ncol=181)

file_name <- "./R/hpop_files/GGM03S.txt"
lines_Cnm_matrix <- readLines(file_name)

line <- 1
for(n in 1:181) {
    for (m in 1:n) {
        line_content <- strsplit(trimws(lines_Cnm_matrix[line]), "\\s+")[[1]]
        Cnm[n, m] <- as.numeric(line_content[3])
        Snm[n, m] <- as.numeric(line_content[4])
        line <- line + 1
    }
} # verified Cnm[103, 30] = 7.629580795415e-10 , Snm[103, 30] = 1.68949165464e-09


earthPositions <- as.matrix(read.table("R/hpop_files/EOP-All.txt"))
colnames(earthPositions) <- c("Date(year)-0h UTC",
                              "Date(month)-0h UTC",
                              "Date(day)-0h UTC",
                              "Modified Julian Date",
                              "x", "y",
                              "UT1 - UTC",
                              "LOD", "dPsi", "dEpsilon",
                              "dX", "dY", "DAT (TAI-UTC)")

spaceWeather <- as.matrix(read.table("R/hpop_files/SW-All.txt"))
colnames(spaceWeather) <- c("Date(year)",
                            "Date(month)",
                            "Date(day)",
                            "BSRN",
                            "ND", paste(rep("Kp", 8), 1:8, sep=""),
                            "Sum", paste(rep("Ap", 8), 1:8, sep=""),
                            "Avg", "Cp", "C9", "ISN", "AdjF10.7", "Q",
                            "AdjCtr81", "AdjLst81", "ObsF10.7", "ObsCtr81",
                            "ObsLst81")

solarStorms <- read.table("R/hpop_files/SOLFSMY.TXT")
colnames(solarStorms) <- c("Year", "Day", "JulianDay", "F10", "F54b",
                           "S10", "S54b", "M10", "M54b", "Y10", "Y54b", "Ssrc")

geomagneticStormsDTC <- read.table("R/hpop_files/DTCFILE.TXT")
colnames(geomagneticStormsDTC) <- c("DTC", "Year", "Day",
                                    paste(rep("DTC", 24), 1:24, sep=""))

geomagneticStormsAP <- read.table("R/hpop_files/SOLRESAP.TXT")
colnames(geomagneticStormsAP) <- c("Day", "F10", "F10B",
                                   paste(rep("Ap", 8), 1:8, sep=""),
                                   "Year", "F")


# Acceleration equations constants
DE436coeffs <- as.matrix(read.csv(unz("R/hpop_files/DE436Coeff.zip", "DE436Coeff.csv"), header=FALSE, sep = ",", dec = "."))
# Table 6.5a IERS 2010
solidEarthTides_dC21dS21 <- as.matrix(read.csv("R/hpop_files/solidEarthTides_dC21dS21.csv", header=FALSE))
# Table 6.5b IERS 2010
solidEarthTides_dC22dS22 <- as.matrix(read.csv("R/hpop_files/solidEarthTides_dC22dS22.csv", header=FALSE))
# Table 6.5c IERS 2010
solidEarthTides_dC20 <- as.matrix(read.csv("R/hpop_files/solidEarthTides_dC20.csv", header=FALSE))

# constants for iauNut00a
xls <- as.matrix(read.csv("R/hpop_files/iauNut00a_xls.csv", header=FALSE))
NLS <- nrow(xls)
xpl <- as.matrix(read.csv("R/hpop_files/iauNut00a_xpl.csv", header=FALSE))
NPL <- nrow(xpl)

# constants for iauS06
sp <- c(94.00e-6, 3808.65e-6, -122.68e-6, -72574.11e-6, 27.98e-6, 15.62e-6)
s_xyD2_coefs <- read.csv("R/hpop_files/s_xyD2_terms.csv", header=FALSE)
s0 <- as.matrix(s_xyD2_coefs[s_xyD2_coefs[, 1] == "ORDER0", -1])
s1 <- as.matrix(s_xyD2_coefs[s_xyD2_coefs[, 1] == "ORDER1", -1])
s2 <- as.matrix(s_xyD2_coefs[s_xyD2_coefs[, 1] == "ORDER2", -1])
s3 <- as.matrix(s_xyD2_coefs[s_xyD2_coefs[, 1] == "ORDER3", -1])
s4 <- as.matrix(s_xyD2_coefs[s_xyD2_coefs[, 1] == "ORDER4", -1])
w0 <- sp[1]
w1 <- sp[2]
w2 <- sp[3]
w3 <- sp[4]
w4 <- sp[5]
w5 <- sp[6]
