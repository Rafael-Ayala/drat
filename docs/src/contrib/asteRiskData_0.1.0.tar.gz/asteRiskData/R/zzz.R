.onLoad  <- function(libname, pkgname) {
    data("nrlmsise00Constants", list=c("Cnm_Snm", "DE436coeffs", "earthPositions", "geomagneticStormsAP",
           "geomagneticStormsDTC", "iauNut00a_constants", "iauS06_constants",
           "solarStorms", "solidEarthTides", "spaceWeather"), package=pkgname,
         envir=parent.env(environment()))
}

.onAttach  <- function(libname, pkgname) {
    packageStartupMessage(strwrap("Run getLatestSpaceData() to obtain the latest
                                  Earth orientation, space weather and solar storms
                                  data"))
}
