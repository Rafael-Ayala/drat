.onLoad  <- function(libname, pkgname) {
    celestrakIP <- suppressWarnings(nsl("celestrak.com"))
    SETIP <- suppressWarnings(nsl("sol.spacenvironment.net"))
    if(!is.null(celestrakIP)) {
        packageStartupMessage("Retrieving latest Earth positions and space weather")
        earthPositionsLines <- readLines("http://www.celestrak.com/SpaceData/EOP-All.txt")
        beginLine <- which(earthPositionsLines=="BEGIN OBSERVED")
        endLine <- which(earthPositionsLines=="END OBSERVED")
        beginLine2 <- which(earthPositionsLines=="BEGIN PREDICTED")
        endLine2 <- which(earthPositionsLines=="END PREDICTED")
        earthPositions_new <- read.table(text=(earthPositionsLines[c((beginLine+1):(endLine-1),
                                                                 (beginLine2+1):(endLine2-1))]))
        colnames(earthPositions_new) <- c("Date(year)-0h UTC",
                                      "Date(month)-0h UTC",
                                      "Date(day)-0h UTC",
                                      "Modified Julian Date",
                                      "x", "y",
                                      "UT1 - UTC",
                                      "LOD", "dPsi", "dEpsilon",
                                      "dX", "dY", "DAT (TAI-UTC)")
        assign("earthPositions", earthPositions_new, parent.env(environment()))
        spaceWeatherLines <- readLines("https://celestrak.com/SpaceData/SW-All.txt")
        beginLine <- which(spaceWeatherLines=="BEGIN OBSERVED")
        endLine <- which(spaceWeatherLines=="END OBSERVED")
        beginLine2 <- which(spaceWeatherLines=="BEGIN DAILY_PREDICTED")
        endLine2 <- which(spaceWeatherLines=="END DAILY_PREDICTED")
        spaceWeather_new <- read.table(text=(spaceWeatherLines[c((beginLine+1):(endLine-1),
                                                             (beginLine2+1):(endLine2-1))]),
                                   fill=TRUE)
        colnames(spaceWeather_new) <- c("Date(year)",
                                    "Date(month)",
                                    "Date(day)",
                                    "BSRN",
                                    "ND", paste(rep("Kp", 8), 1:8, sep=""),
                                    "Sum", paste(rep("Ap", 8), 1:8, sep=""),
                                    "Avg", "Cp", "C9", "ISN", "AdjF10.7", "Q",
                                    "AdjCtr81", "AdjLst81", "ObsF10.7", "ObsCtr81",
                                    "ObsLst81")
        assign("spaceWeather", spaceWeather_new, parent.env(environment()))
    }
    if(!is.null(SETIP)) {
        packageStartupMessage("Retrieving latest Jacchia-Bowman 2008 indices")
        solarStorms_new <- read.table("https://sol.spacenvironment.net/jb2008/indices/SOLFSMY.TXT",
                                  skip=3)
        colnames(solarStorms_new) <- c("Year", "Day", "JulianDay", "F10", "F54b",
                                   "S10", "S54b", "M10", "M54b", "Y10", "Y54b", "Ssrc")
        assign("solarStorms", solarStorms_new, parent.env(environment()))
        geomagneticStormsDTC_new <- read.table("https://sol.spacenvironment.net/jb2008/indices/DTCFILE.TXT")
        colnames(geomagneticStormsDTC_new) <- c("DTC", "Year", "Day",
                                            paste(rep("DTC", 24), 1:24, sep=""))
        assign("geomagneticStormsDTC", geomagneticStormsDTC_new, parent.env(environment()))
        geomagneticStormsAP_new <- read.table("https://sol.spacenvironment.net/jb2008/indices/DTCFILE.TXT")
        colnames(geomagneticStormsAP_new) <- c("Day", "F10", "F10B",
                                           paste(rep("Ap", 8), 1:8, sep=""),
                                           "Year", "F")
        assign("geomagneticStormsAP", geomagneticStormsAP_new, parent.env(environment()))
    }
}
