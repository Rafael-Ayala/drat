getLatestSpaceData_ <- function(targets) {
    celestrakIP <- suppressWarnings(nslookup("celestrak.com"))
    SETIP <- suppressWarnings(nslookup("sol.spacenvironment.net"))
    if(is.null(celestrakIP) | is.null(SETIP)) {
        stop("Online resources currently not available")
    }
    if(!all(targets %in% c("all", "EOP", "SW", "SS", "GS"))) {
        warning(strwrap("Unrecognized targets to be updated. Possible values are
                        all, EOP (Earth orientation parameters), SW (space weather),
                        SS (solar storms) and GS (geomagnetic storms). Updating
                        all data by default.", initial="", prefix="\n"),
                immediate. = TRUE)
        targets <- "all"
    }
    if("all" %in% targets | "EOP" %in% targets) {
        message("Updating Earth positions ...")
        earthPositionsLines <- readLines("https://celestrak.org/SpaceData/EOP-All.txt")
        beginLine <- which(earthPositionsLines=="BEGIN OBSERVED")
        endLine <- which(earthPositionsLines=="END OBSERVED")
        beginLine2 <- which(earthPositionsLines=="BEGIN PREDICTED")
        endLine2 <- which(earthPositionsLines=="END PREDICTED")
        earthPositions_new <- read.table(text=(earthPositionsLines[c((beginLine+1):(endLine-1),
                                                                     (beginLine2+1):(endLine2-1))]))
        colnames(earthPositions_new) <- c("Date(year)-0h UTC",
                                          "Date(month)-0h UTC",
                                          "Date(day)-0h UTC",
                                          "Modified Julian Date",
                                          "x", "y",
                                          "UT1 - UTC",
                                          "LOD", "dPsi", "dEpsilon",
                                          "dX", "dY", "DAT (TAI-UTC)")
        assignInMyNamespace("earthPositions", as.matrix(earthPositions_new))
    }
    if("all" %in% targets | "SW" %in% targets) {
        message("Updating space weather data ...")
        spaceWeatherLines <- readLines("https://celestrak.org/SpaceData/SW-All.txt")
        beginLine <- which(spaceWeatherLines=="BEGIN OBSERVED")
        endLine <- which(spaceWeatherLines=="END OBSERVED")
        beginLine2 <- which(spaceWeatherLines=="BEGIN DAILY_PREDICTED")
        endLine2 <- which(spaceWeatherLines=="END DAILY_PREDICTED")
        spaceWeather_new <- read.table(text=(spaceWeatherLines[c((beginLine+1):(endLine-1),
                                                                 (beginLine2+1):(endLine2-1))]),
                                       fill=TRUE)
        colnames(spaceWeather_new) <- c("Date(year)",
                                        "Date(month)",
                                        "Date(day)",
                                        "BSRN",
                                        "ND", paste(rep("Kp", 8), 1:8, sep=""),
                                        "Sum", paste(rep("Ap", 8), 1:8, sep=""),
                                        "Avg", "Cp", "C9", "ISN", "AdjF10.7", "Q",
                                        "AdjCtr81", "AdjLst81", "ObsF10.7", "ObsCtr81",
                                        "ObsLst81")
        assignInMyNamespace("spaceWeather", as.matrix(spaceWeather_new))
    }
    if("all" %in% targets | "SS" %in% targets) {
        message("Updating solar storms data ...")
        solarStorms_new <- read.table("https://sol.spacenvironment.net/jb2008/indices/SOLFSMY.TXT",
                                      skip=3)
        colnames(solarStorms_new) <- c("Year", "Day", "JulianDay", "F10", "F54b",
                                       "S10", "S54b", "M10", "M54b", "Y10", "Y54b", "Ssrc")
        solarStorms_new <- solarStorms_new[, -ncol(solarStorms_new)]
        assignInMyNamespace("solarStorms", as.matrix(solarStorms_new))
    }
    if("all" %in% targets | "GS" %in% targets) {
        message("Updating geomagnetic storms data ...")
        geomagneticStormsDTC_new <- read.table("https://sol.spacenvironment.net/jb2008/indices/DTCFILE.TXT")
        colnames(geomagneticStormsDTC_new) <- c("DTC", "Year", "Day",
                                                paste(rep("DTC", 24), 1:24, sep=""))
        geomagneticStormsDTC_new <- geomagneticStormsDTC_new[,-1]
        geomagneticStormsDTC_new <- as.matrix(geomagneticStormsDTC_new)
        assignInMyNamespace("geomagneticStormsDTC", as.matrix(geomagneticStormsDTC_new))
        geomagneticStormsAP_new <- read.table("https://sol.spacenvironment.net/jb2008/indices/DTCFILE.TXT")
        colnames(geomagneticStormsAP_new) <- c("Day", "F10", "F10B",
                                               paste(rep("Ap", 8), 1:8, sep=""),
                                               "Year", "F")
        geomagneticStormsAP_new <- geomagneticStormsAP_new[,-ncol(geomagneticStormsAP_new)]
        geomagneticStormsAP_new <- as.matrix(geomagneticStormsAP_new)
        assignInMyNamespace("geomagneticStormsAP", as.matrix(geomagneticStormsAP_new))
    }
    message("All requested data successfully updated")
}
