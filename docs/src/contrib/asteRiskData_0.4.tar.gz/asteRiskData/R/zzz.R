.onLoad  <- function(libname, pkgname) {
    data("nrlmsise00Constants", list=c("Cnm_Snm", "DE440coeffs", "earthPositions", "geomagneticStormsAP",
           "geomagneticStormsDTC", "iauNut00a_constants", "iauS06_constants",
           "solarStorms", "solidEarthTides", "spaceWeather", "nut_IAU1980", "oceanTides"), package=pkgname,
         envir=parent.env(environment()))
}

.onAttach  <- function(libname, pkgname) {
    packageStartupMessage(strwrap("Run getLatestSpaceData() to obtain the latest
                                  Earth orientation, space weather, solar storms
                                  and geomagnetic storms data"))
}
